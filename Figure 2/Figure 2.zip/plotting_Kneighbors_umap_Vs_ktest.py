import numpy as np
from mpl_toolkits.axes_grid1 import make_axes_locatable

# Parameters for this script
n_neighbors=np.arange(9, 35, 1)            # neighbors for umap   Default in 30

#--------------------------------------------------------------------------------------------------------------
# importing libraries
from scipy.io import loadmat
#import spikeforest as sf
import matplotlib.pyplot as plt
#from busz_funcs import pk, pts_extraction, butter_bandpass_filter_zi, load_kachery
#from toposort.preprocessing import spike_denoiser as denoiser, spike_aligner as aligner
import umap
import hdbscan
from scipy.spatial.distance import cdist
import seaborn as sns
import pandas as pd
from sklearn.decomposition import PCA 
from sklearn.metrics.cluster import adjusted_mutual_info_score
#from quiroga import *
from matplotlib.colors import ListedColormap
import matplotlib.gridspec as gridspec
import random
#import umap.plot
import pywt
from scipy import stats
import pickle as pkl        # probably Vik needs to install this library, 
import SpkSort as s
from os import path as p
from os import listdir
#plt.style.use('fivethirtyeight')
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

# FOr silencing warnings
import warnings
warnings.filterwarnings("ignore")
namefiles= ("C_Easy1_noise005.mat",
             "C_Easy1_noise01.mat",
             "C_Easy1_noise015.mat",
             "C_Easy1_noise02.mat",
             "C_Difficult1_noise005.mat",
             "C_Difficult1_noise01.mat",
             "C_Difficult1_noise015.mat",
             "C_Difficult1_noise02.mat",
             "C_Difficult2_noise005.mat",
             "C_Difficult2_noise01.mat",
             "C_Difficult2_noise015.mat",
             "C_Difficult2_noise02.mat",)


with open("Nneighbors_umap_Vs_kstest.pkl", "rb") as file1:
    data=pkl.load(file1)
    data=data["cluster"]
pooled=[]
ytick=[]
for file_i in namefiles:
   # print(file_i)
    if "Easy" in file_i:
        part="E"
    elif "Difficult1" in file_i:
        part="D1"
    elif "Difficult2" in file_i:
        part="D2"
    else:
        print(file_i)
        print(data.keys())
        raise ValueError("Upsss unkonow files")
        
    part=part + " $\eta$=" + str(data[file_i]["noise"])
    ytick.append(part)
    pooled.append(data[file_i]["values"])
pooled=np.vstack(pooled)

fig, ax=plt.subplots(1, 1, figsize=(7.7, 5))
h=ax.imshow(pooled, extent=(n_neighbors[0], n_neighbors[-1], 1, len(pooled)))
ax.set_ylabel("Dataset")
ax.set_xlabel("N neighbors, UMAP's parameter")
#print(help(ax.yaxis.set_ticklabels))
ax.yaxis.set_ticks(np.arange(1, len(pooled)+1))
ytick2=ytick[-1: :-1]
ax.yaxis.set_ticklabels(ytick2)
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.05)
cbar=plt.colorbar(h, cax=cax)
cbar.set_label('Kolmogorov statistic', rotation=270, size=10, labelpad=12)
#fig.tight_layout()
#fig.tight_layout()
plt.show(block=False)
fig.savefig("Optimization_parameter_UMAP.svg")
fig.savefig("Optimization_parameter_UMAP.png", dpi=500)