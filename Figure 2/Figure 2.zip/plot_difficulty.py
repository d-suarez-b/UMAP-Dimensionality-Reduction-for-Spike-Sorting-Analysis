import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt

with open("Difficulty_2_to_15_pca_wav_conf_mat.pkl", 'rb') as f:
    data=pkl.load(f)


data=data["DaviesBouldin"]
dimm=np.arange(2, 15)
dimmpool=[]
difficultipool={"umap":[], "pca":[], "waveclus":[]}
for file_i in data.keys():
    for reducer_i in data[file_i].keys():
        if reducer_i=="noise":
            continue
        difficultipool[reducer_i].append(data[file_i][reducer_i])
    dimmpool.append(dimm)

# Now plottttttttttttt
fig, ax=plt.subplots(1, 1)
x=np.hstack(dimmpool)
for reducer_i in difficultipool.keys():
    y=np.hstack(difficultipool[reducer_i])
    plt.hist(y, label=reducer_i, alpha=.85, lw=3, cumulative=True, density=True,
             bins=np.linspace(0, 100, 300), histtype='step', )
plt.legend()
ax.set_xlabel("Difficulty [DaviesBouldin index]")
ax.set_ylabel("Frequency")
plt.title("Difficulty")
ax.spines[['right', 'top']].set_visible(False)
fig.tight_layout()
plt.xlim(0, 20)
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig.savefig("Difficulty.svg")







