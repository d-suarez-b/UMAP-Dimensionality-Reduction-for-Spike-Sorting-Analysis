# Now plotting
import pickle as pkl
import matplotlib.pyplot as plt
from matplotlib import colormaps
from numba import njit
import numpy as np
import sys
import itertools as it

plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
x=np.arange(2, 15)
# Functions

# You can now retrieve arguments passed from the calling script
inputfile = sys.argv[1]        # file 1: Scores
inputfile2=sys.argv[2]         # File 2: Difficulty
nboots=int(sys.argv[3])            # Number of bootstrap repetitions
#-------
with open (inputfile, "rb") as f:
    data=pkl.load(f)

with open (inputfile2, "rb") as f:
    data2=pkl.load(f)
diff=data2['DaviesBouldin']

files=('C_Easy1_noise01.mat', 'C_Easy1_noise02.mat', 'C_Easy1_noise005.mat', 'C_Easy1_noise015.mat', 'C_Difficult1_noise01.mat', 'C_Difficult1_noise02.mat', 'C_Difficult1_noise005.mat', 'C_Difficult1_noise015.mat', 'C_Difficult2_noise01.mat', 'C_Difficult2_noise02.mat', 'C_Difficult2_noise005.mat', 'C_Difficult2_noise015.mat')

c=["red", "green", "magenta", "blue"]
techs=["pca", "waveclus", "umap"]

for metric_idx, metric_i in enumerate(data.keys()):
    pooling_data={"pca":[], "waveclus":[], "umap":[]}
    pooling_diff={"pca":[], "waveclus":[], "umap":[]}
    for file_i in files:
        for col_idx, tech_i in enumerate(techs):
            pooling_data[tech_i].append(data[metric_i][file_i][tech_i])
            pooling_diff[tech_i].append(diff[file_i][tech_i])

    for col_idx, tech_i in enumerate(techs):
        tmp=np.array(pooling_data[tech_i]).flatten()
        tmp2=np.array(pooling_diff[tech_i]).flatten()
        if col_idx==0:
            diff_mat=np.zeros((len(tmp), len(techs)))
            score_mat=np.zeros((len(tmp), len(techs)))
        diff_mat[:, col_idx]=np.copy(tmp2)
        score_mat[:, col_idx]=np.copy(tmp)

    # Now calculating the bootstrap 
    num_l = np.arange(len(techs))
    num_combs_l = list( it.combinations(num_l, 2)) 
    for comb_idx, comb_i in enumerate(num_combs_l):
        tmp=score_mat[:, comb_i].flatten()
        bines=np.histogram_bin_edges(tmp, bins="fd")
        hist, _=np.histogram(score_mat[:, comb_i[0]], bins=bines)
        hist2, _=np.histogram(score_mat[:, comb_i[1]], bins=bines)
        hist=np.cumsum(hist)/len(score_mat)
        hist2=np.cumsum(hist2)/len(score_mat)
        uno=np.insert(hist, [0], 0)
        dos=np.insert(hist2, [0], 0)
        AUROC=np.trapz(uno, dos)    
        AUROC= 1-AUROC if AUROC<0.5 else AUROC           # AUROC calculation
        bootstrap=np.zeros(nboots, dtype=np.float32)
        # Now bootstrap
        for boot_i in range(nboots):
            selection=np.random.choice(np.arange(len(score_mat)), size=len(score_mat))
            hist,  _=np.histogram(score_mat[selection, comb_i[0]], bins=bines)
            hist2, _=np.histogram(score_mat[selection, comb_i[1]], bins=bines)
            hist=np.cumsum(hist)/len(score_mat)
            hist2=np.cumsum(hist2)/len(score_mat)
            uno=np.insert(hist, [0], 0)
            dos=np.insert(hist2, [0], 0)
            AUROCtmp=np.trapz(uno, dos)    
            AUROCtmp= 1-AUROCtmp if AUROCtmp<0.5 else AUROCtmp            
            bootstrap[boot_i]= AUROCtmp
        plt.figure(), plt.hist(bootstrap, bins=10, density=True), 
        plt.title("%s, %s"%(techs[comb_i[0]], techs[comb_i[1]])),plt.show(block=False)
        sgm=np.std(bootstrap)
        print("################ %s #######################"%(metric_i))
        print("Bootstrap: %s, %s"%(techs[comb_i[0]], techs[comb_i[1]]))
        print("AUROC= %.4f $$\pm$$ %.4f, mean=%.4f, nboot:%d\n"%(AUROC, 2*sgm, np.mean(bootstrap),  nboots))
        # # Now permutations
        # perm_Au_supra_tac=np.zeros(nperm, dtype=np.float32)
        # rf1_3b_1=np.concatenate((rf1_3b, rf1_1))
        # n3b=len(rf1_3b)
        # for perm_i in range(nperm):
        #     np.random.shuffle(rf1_3b_1)
        #     tmp=rate_p_amp[rf1_3b_1[:n3b],:][:,(9, 10)].flatten()
        #     tmp=tmp[~(np.isnan(tmp))]
        #     hist, _=np.histogram(tmp, bins=bines)
        #     hist=np.cumsum(hist)/len(tmp)
        #     uno=np.insert(hist, [0], 0)
        #     # Now the other area
        #     tmp=rate_p_amp[rf1_3b_1[n3b::],:][:,(9, 10)].flatten()
        #     tmp=tmp[~(np.isnan(tmp))]
        #     hist, _=np.histogram(tmp, bins=bines)
        #     hist=np.cumsum(hist)/len(tmp)
        #     dos=np.insert(hist, [0], 0)
        #     tmp=np.trapz(uno, dos)    
        #     perm_Au_supra_tac[perm_i]= 1-tmp if tmp<0.5 else tmp # AUROC calculation
        # plt.figure(), plt.hist(perm_Au_supra_tac, bins=20), plt.show(block=False)
        # p=np.sum(perm_Au_supra_tac>AUROC)/nperm
        
        # print("AUROC= %.4f $$\pm$$ %.4f, p=%.4f, nboot:%d, nperm: %d"%(AUROC, sgm, p, nboot, nperm))
for comb_idx, comb_i in enumerate(num_combs_l):
    tmp=diff_mat[:, comb_i].flatten()
    bines=np.histogram_bin_edges(tmp, bins="fd")
    hist, _=np.histogram(diff_mat[:, comb_i[0]], bins=bines)
    hist2, _=np.histogram(diff_mat[:, comb_i[1]], bins=bines)
    hist=np.cumsum(hist)/len(diff_mat)
    hist2=np.cumsum(hist2)/len(diff_mat)
    uno=np.insert(hist, [0], 0)
    dos=np.insert(hist2, [0], 0)
    AUROC=np.trapz(uno, dos)    
    AUROC= 1-AUROC if AUROC<0.5 else AUROC           # AUROC calculation
    bootstrap=np.zeros(nboots, dtype=np.float32)
    # Now bootstrap
    for boot_i in range(nboots):
        selection=np.random.choice(np.arange(len(diff_mat)), size=len(diff_mat))
        hist,  _=np.histogram(diff_mat[selection, comb_i[0]], bins=bines)
        hist2, _=np.histogram(diff_mat[selection, comb_i[1]], bins=bines)
        hist=np.cumsum(hist)/len(diff_mat)
        hist2=np.cumsum(hist2)/len(diff_mat)
        uno=np.insert(hist, [0], 0)
        dos=np.insert(hist2, [0], 0)
        AUROCtmp=np.trapz(uno, dos)    
        AUROCtmp= 1-AUROCtmp if AUROCtmp<0.5 else AUROCtmp            
        bootstrap[boot_i]= AUROCtmp
    plt.figure(), plt.hist(bootstrap, bins=10, density=True), 
    plt.title("%s, %s"%(techs[comb_i[0]], techs[comb_i[1]])),plt.show(block=False)
    sgm=np.std(bootstrap)
    print("################ Diffficulty #######################")
    print("Bootstrap: %s, %s"%(techs[comb_i[0]], techs[comb_i[1]]))
    print("AUROC= %.4f $$\pm$$ %.4f, mean=%.4f, nboot:%d\n"%(AUROC, 2*sgm, np.mean(bootstrap),  nboots))