import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt

namefiles=("Deletion_from_2_to_15_umap_pca_wav_20reps_C_Easy1_noise005.pkl", 
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Easy1_noise015.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_easy_C_Easy1_noise01.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_easy_C_Easy1_noise02.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult1_noise02.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult1_noise01.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult1_noise005.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult1_noise015.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult2_noise01.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult2_noise02.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult2_noise005.pkl",
           "Deletion_from_2_to_15_umap_pca_wav_20reps_C_Difficult2_noise015.pkl",
           )
# Preparing matrix for data
# The best value for all dimensions in every rep, the total rep (60) X dilution(5) Xnoise level (4)
data_colapse={ "umap":    np.zeros((20*3, 5, 4)),
               "pca":     np.zeros((20*3, 5, 4)),
               "waveclus":np.zeros((20*3, 5, 4))   }
noise_lvls=np.array([0.05, 0.1, 0.15, 0.2])
limits={"pca": [0,   60], "umap":[0, 60], "waveclus":[0, 60]}

# Extraction for relevant information
for file_idx, file_i in enumerate(namefiles):
    with open(file_i, "rb") as f:
        data_tmp=pkl.load(f)
    fk=list(data_tmp.keys())[0]
    #print(data_tmp[fk]["umap"][0, :, 0, 0])
    kindex=np.argmin(np.abs(noise_lvls-data_tmp[fk]["noise"]))
    for red_i in ("umap", "pca", "waveclus"):
        colapsing=np.nanmax(data_tmp[fk][red_i], axis=0) # Extract the maximum in the rows.
        #print(red_i, "noise: %f"%(data_tmp[fk]["noise"]), str(kindex))
        for dil_i in range(5):  # Five elements in the dilution
            #print(colapsing[dil_i, :, :])
            data_colapse[red_i][:, dil_i, kindex]=np.copy(colapsing[dil_i, :, :].reshape((60)))

# Creating picture
c={"umap":"midnightblue", "waveclus":"darkgreen", "pca":"darkorange"}
leg={"umap":"UMAP", "waveclus":"Wavelets", "pca":"PCA"}
alpha=np.linspace(0.3, 1, 4)

dil_axis=np.arange(0.2, 1.05, 0.2)
noise_axis=np.array([0.05, 0.1, 0.15, 0.2])
fig, ax=plt.subplots(1, 1)
fig2, ax2=plt.subplots(1, 3, sharey=True)

for r_idx, red_i in enumerate(("pca", "waveclus", "umap")):
    ymean=np.zeros(5)
    yerr=np.zeros(5)
    for dil_i in range(5):
        ymean[dil_i]=np.nanmean(data_colapse[red_i][:, dil_i, :])
        yerr[dil_i]=np.nanstd(data_colapse[red_i][:, dil_i, :])
    ax.errorbar(dil_axis, ymean, yerr, label=leg[red_i], c=c[red_i], lw=3 )
    # Now plotting at the second figure
    ax2[r_idx].set_title(leg[red_i])
    for n_idx in range(4):
        y=np.nanmean(data_colapse[red_i][:, :, n_idx], axis=0)
        ystd=np.nanstd(data_colapse[red_i][:, :, n_idx], axis=0)
        ax2[r_idx].errorbar(dil_axis, y, yerr=ystd, 
                      c=c[red_i], lw=3, alpha=alpha[n_idx])

#Makeup for the first figure
ax.legend(loc="best", frameon=False)
ax.spines[['right', 'top']].set_visible(False)
ax.set_xlabel("Fraction of spikes")
ax.set_ylabel("Fscore")
fig.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig.savefig("Fscore_vs_fractions_all-files.svg", format="svg")

# Makeup for the second figure
for ax_i in ax2:
    ax_i.spines[['right', 'top']].set_visible(False)
    ax_i.set_xlabel("Fraction of spikes")
ax2[0].set_ylabel("F-score")
fig2.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
fig2.savefig("Fscore_vs_fractions_all-files_b.svg", format="svg")
plt.show(block=False)
