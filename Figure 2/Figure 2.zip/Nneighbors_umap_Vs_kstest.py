import numpy as np

# Parameters for this script
n_neighbors=np.arange(9, 35, 1)            # neighbors for umap   Default in 30

#--------------------------------------------------------------------------------------------------------------
# importing libraries
from scipy.io import loadmat
#import spikeforest as sf
import matplotlib.pyplot as plt
#from busz_funcs import pk, pts_extraction, butter_bandpass_filter_zi, load_kachery
#from toposort.preprocessing import spike_denoiser as denoiser, spike_aligner as aligner
import umap
import hdbscan
from scipy.spatial.distance import cdist
import seaborn as sns
import pandas as pd
from sklearn.decomposition import PCA 
from sklearn.metrics.cluster import adjusted_mutual_info_score
#from quiroga import *
from matplotlib.colors import ListedColormap
import matplotlib.gridspec as gridspec
import random
#import umap.plot
import pywt
from scipy import stats
import pickle as pkl        # probably Vik needs to install this library, 
import SpkSort as s
from os import path as p
from os import listdir
#plt.style.use('fivethirtyeight')
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

# FOr silencing warnings
import warnings
warnings.filterwarnings("ignore")



def parameter(data):
    KSstat= np.zeros(2)
    for ii in range(2):
        pd =stats.norm.fit(data[:,ii])  #Estima parametros mu y sigma de los datos, 
                                            #ajustandolos a la distribucion normal
        mu = pd[0]
        sigma = pd[1]
        if sigma != 0:  #Esta parte se agrego por errores en algunas sesiones
            Data= (data[:,ii]- mu)/ sigma  #Normalizacion Z-score
            KSstat[ii], _= stats.kstest(Data, 'norm')  #KS test
        else:
            KSstat[ii]= np.zeros(1, dtype="float")
    return np.mean(KSstat)
#
path="/media/sparra/HDD/article_spike_sorting/Simulator/"
namefiles1= ( ("C_Easy1_noise01.mat", 0.1),
             ("C_Easy1_noise02.mat",  0.2),
            ("C_Easy1_noise005.mat", 0.05),
            ("C_Easy1_noise015.mat", 0.15),
            )

namefiles2= (("C_Difficult2_noise01.mat",  0.1),
            ( "C_Difficult2_noise02.mat",  0.2),
            ("C_Difficult2_noise005.mat", 0.05),
             ("C_Difficult2_noise015.mat", 0.15))

namefiles3=(("C_Difficult1_noise01.mat", 0.1),
             ("C_Difficult1_noise02.mat", 0.2),
             ("C_Difficult1_noise005.mat", 0.05),
             ("C_Difficult1_noise015.mat", 0.15))

files={"easy":namefiles1, "difficult1":namefiles3, "difficult2":namefiles2}
grupos={}
types_file=files.keys()   

for type_i in types_file:
    print("Executing %s files"%(type_i))
    for file_i in files[type_i]:   
        # Dictionary with results per type of file
        print("\tAnalyzing %s file"%(file_i[0]))
        grupos[file_i[0]]={"noise":file_i[1],
                        "values": np.zeros((len(n_neighbors))), }    
        spikes, labels, spike_times = s.load_quiroga_spikes(p.join(path, file_i[0]) )  
        clusters=np.unique(labels)
        denoised = s.denoiser(spikes)
        spikes2 = s.aligner(denoised, alignment="tukey", window_length=30, upsample_rate=8)
        # Calculating values with the whole set
        #reducer_waveclus = s.waveclus(spikes2, maximum_features)
        #reducer_pca= PCA(maximum_features).fit_transform(spikes2)
        clasification={}          # Resetting values
        for neigh_idx, N_neigh_i in enumerate(n_neighbors):
            reducer_umap= umap.UMAP(min_dist=0, n_neighbors=N_neigh_i, n_components=2, n_epochs=2000, random_state=0, metric="manhattan").fit(spikes2)
            umap_emb = reducer_umap.embedding_.copy()
            # clusterer_umap = hdbscan.HDBSCAN(min_cluster_size=55, min_samples=50, cluster_selection_epsilon=.35).fit(reducer_umap.embedding_)  #orig 30, 5, 0.6
            # clasification["values"] = clusterer_umap.labels_

            grupos[file_i[0]]["values"][neigh_idx]=parameter(umap_emb)

    # Saving results to a file
with open("Nneighbors_umap_Vs_kstest.pkl", "wb") as file1:
    pkl.dump({f"cluster":grupos}, file1)
print("Finished...")