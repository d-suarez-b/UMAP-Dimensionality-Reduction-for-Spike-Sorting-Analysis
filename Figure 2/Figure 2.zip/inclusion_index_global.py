# Parameters for this script
fscore_results={}         # dictionary where results will be saved
Index_Inclusion={}        # dictionary where results will be saved
ami={}                    # dictionary where results will be saved
delta=5                   # Parameter to indicate if both spikes are the same shifted in samples (delta*0.04166667 in ms)
min_features=2            # Minimimum dimensionality or # of components to explore.
maximum_features=15       # Maximum dimensionality to explore
n_neighbors=30            # neighbors for umap   Default in 30

#--------------------------------------------------------------------------------------------------------------
# importing libraries
import numpy as np
from scipy.io import loadmat
#import spikeforest as sf
import matplotlib.pyplot as plt
#from busz_funcs import pk, pts_extraction, butter_bandpass_filter_zi, load_kachery
#from toposort.preprocessing import spike_denoiser as denoiser, spike_aligner as aligner
import umap
import hdbscan
from scipy.spatial.distance import cdist
import seaborn as sns
import pandas as pd
from sklearn.decomposition import PCA 
from sklearn.metrics.cluster import adjusted_mutual_info_score
#from quiroga import *
from matplotlib.colors import ListedColormap
import matplotlib.gridspec as gridspec
import random
#import umap.plot
import pywt
from scipy import stats
import pickle as pkl        # probably Vik needs to install this library, 
import SpkSort as s
from os import path as p
from os import listdir
#plt.style.use('fivethirtyeight')
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

# FOr silencing warnings
import warnings
warnings.filterwarnings("ignore")

#
path="/media/sparra/HDD/article_spike_sorting/Simulator/"
namefiles1= ( ("C_Easy1_noise01.mat", 0.1),
             ("C_Easy1_noise02.mat", 0.2),
            #  ("C_Easy1_noise03.mat", 0.3),
            # ("C_Easy1_noise04.mat", 0.4),
            ("C_Easy1_noise005.mat", 0.05),
            ("C_Easy1_noise015.mat", 0.15),
            # ("C_Easy1_noise025.mat", 0.25),
            # ("C_Easy1_noise035.mat", 0.35)
            )

namefiles2= (("C_Difficult2_noise01.mat", 0.1),
            ( "C_Difficult2_noise02.mat", 0.2),
            ("C_Difficult2_noise005.mat", 0.05),
             ("C_Difficult2_noise015.mat", 0.15))

namefiles3=(("C_Difficult1_noise01.mat", 0.1),
             ("C_Difficult1_noise02.mat", 0.2),
             ("C_Difficult1_noise005.mat", 0.05),
             ("C_Difficult1_noise015.mat", 0.15))

files={"easy":namefiles1, "difficult1":namefiles3, "difficult2":namefiles2}

types_file=files.keys()   

for type_i in types_file:
    print("Executing %s files"%(type_i))
    for file_i in files[type_i]:   
        # Dictionary with results per type of file
        print("\tAnalyzing %s file"%(file_i[0]))
        fscore_results[file_i[0]]={"noise":file_i[1],
                        "pca": np.zeros((maximum_features-min_features)), 
                        "umap": np.zeros(maximum_features-min_features), 
                        "waveclus": np.zeros(maximum_features-min_features)}  

        Index_Inclusion[file_i[0]]={"noise":file_i[1],
                        "pca": np.zeros((maximum_features-min_features)), 
                        "umap": np.zeros(maximum_features-min_features), 
                        "waveclus": np.zeros(maximum_features-min_features)}  

        ami[file_i[0]]={"noise":file_i[1],
                "pca": np.zeros((maximum_features-min_features)), 
                "umap": np.zeros(maximum_features-min_features), 
                "waveclus": np.zeros(maximum_features-min_features)}  
        #  NOW CONFUSION MATRIX   Here, I don't save the matrix form
        # confmat_results[file_i[0]]={"noise":file_i[1],
        #         "pca":      [], 
        #         "umap":     [], 
        #         "waveclus": []} 
        spikes, labels, spike_times = s.load_quiroga_spikes(p.join(path, file_i[0]) )  
        clusters=np.unique(labels)
        denoised = s.denoiser(spikes)
        spikes2 = s.aligner(denoised, alignment="tukey", window_length=30, upsample_rate=8)
        # Calculating values with the whole set
        reducer_waveclus = s.waveclus(spikes2, maximum_features)
        reducer_pca= PCA(maximum_features).fit_transform(spikes2)
        clasification={}          # Resetting values
        for dim_i in range(min_features, maximum_features):
            clusterer_waveclus= hdbscan.HDBSCAN(min_cluster_size=55, min_samples=50, cluster_selection_epsilon=.35).fit(reducer_waveclus[:, 0:dim_i]) #orig 30, 5, 0.6
            clasification["waveclus"]= clusterer_waveclus.labels_
            #  sep per technique
            clusterer_pca= hdbscan.HDBSCAN(min_cluster_size=55, min_samples=50, cluster_selection_epsilon=.35).fit(reducer_pca[:, 0:dim_i])  #orig 30, 5, 0.6
            clasification["pca"]= clusterer_pca.labels_
            
            reducer_umap= umap.UMAP(min_dist=0, n_neighbors=n_neighbors, n_components=dim_i, n_epochs=2000, random_state=0, metric="manhattan").fit(spikes2)
            umap_emb = reducer_umap.embedding_.copy()
            clusterer_umap = hdbscan.HDBSCAN(min_cluster_size=55, min_samples=50, cluster_selection_epsilon=.35).fit(reducer_umap.embedding_)  #orig 30, 5, 0.6
            clasification["umap"] = clusterer_umap.labels_
            # Now measure f-score per file and techinique
            #raise ValueError("Aqui vamos")
            for technique_i in clasification.keys():
                fscore_tmp, inclusion_index =s.f_recording2(spike_times, labels, clasification[technique_i], delta, return_conf_mat=False)
                fscore_tmp, matrix =s.f_recording(spike_times, labels, clasification[technique_i], delta, return_conf_mat=True)
                fscore_results[file_i[0]][technique_i][dim_i-min_features]=fscore_tmp
                Index_Inclusion[file_i[0]][technique_i][dim_i-min_features]=inclusion_index
                ami[file_i[0]][technique_i][dim_i-min_features]=adjusted_mutual_info_score(labels, clasification[technique_i])
# Saving results to a file
with open("Analysis_from_%d_to_%d_pca_wav_incl_index_UMAP_%d_new_method.pkl"%(min_features, maximum_features, n_neighbors), "wb") as file1:
    pkl.dump({f"fscore":fscore_results, "Index_Inclusion":Index_Inclusion, "ami":ami}, file1)
print("Finished...")