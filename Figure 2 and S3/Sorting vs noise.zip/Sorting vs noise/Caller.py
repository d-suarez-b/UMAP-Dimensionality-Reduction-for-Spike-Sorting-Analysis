import subprocess
import numpy as np


file_i ="Analysis_from_2_to_15_pca_wav_incl_index_UMAP_30_new_method.pkl"   # Name of file

subprocess.run(['python', 'Inclusion_index_mean_Vs_Dimmensions.py', file_i])

#Inclusion_index_mean_Vs_Dimmensions.py
#'Plotting_dimmensions_vs_scores'