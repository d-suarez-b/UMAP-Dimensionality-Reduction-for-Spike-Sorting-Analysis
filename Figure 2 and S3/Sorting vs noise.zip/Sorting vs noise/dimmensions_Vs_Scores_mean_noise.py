# Now plotting
import pickle as pkl
import matplotlib.pyplot as plt
from matplotlib import colormaps
import numpy as np
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

x=np.arange(2, 15)
#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#                            Parameters for this script
#----------------------------------------------------------------------------------------------------------------------
                        
# You can now retrieve arguments passed from the calling script
inputfile = "Analysis_from_2_to_15_pca_wav_incl_index_UMAP_30_new_method.pkl"       # nreps=20    # Number of repetitions for every fraction (estimation of the f-score)
#-------
with open (inputfile, "rb") as f:
    data=pkl.load(f)
noise=np.array([0.05, 0.1, 0.15, 0.2])
c=["red", "green", "magenta", "blue"]
line_labels = ["$\eta$: %.2f"%(noise[idx]) for idx in range(len(noise)) ]

namefiles1= ( "C_Easy1_noise005.mat",
              "C_Difficult1_noise005.mat",
             "C_Difficult2_noise005.mat")

    
namefiles2= ("C_Easy1_noise01.mat", 
            "C_Difficult2_noise01.mat", 
            "C_Difficult1_noise01.mat")
             
            
namefiles3=("C_Difficult2_noise015.mat",
            "C_Difficult1_noise015.mat",
             "C_Easy1_noise015.mat")

namefiles4= ("C_Difficult1_noise02.mat", 
             "C_Easy1_noise02.mat", 
             "C_Difficult2_noise02.mat")
namefiles=(namefiles1, namefiles2, namefiles3, namefiles4)

techs=["pca", "waveclus", "umap"]
for metric_i in data.keys():
    fig, ax=plt.subplots(1, 3, sharex=True, sharey=True, figsize=(14, 4))
    fig.suptitle(metric_i), 
    for noise_idx, noise_i in enumerate(namefiles):   # Noise level
        tmp=np.zeros((3, len(x)))               
        for file_i in range(3):                       # file_i 3 in total
            for col_idx, tech_i in enumerate(techs):
                tmp[col_idx, :]=tmp[col_idx, :] + (data[metric_i][noise_i[file_i]][tech_i])/3
                
        for col in range(3):
            ax[col].plot(x, tmp[col, :], color=c[noise_idx],
                             label="$\eta = %.2f$"%(noise[noise_idx]))
            
            ax[col].spines[["right", "top"]].set_visible(False)
        
    ax[-1].legend(loc="best", frameon=False, bbox_to_anchor=(1.1, 1.05))
    
    for idx in range(3):
        ax[0].set_ylabel(metric_i)
        ax[idx].set_xlabel("Dimmensions")
        ax[idx].set_title(techs[idx].upper())
    

    plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
    fig.tight_layout()
    fig.savefig("%s_%s_all_mean_noise.svg"%(metric_i, inputfile), format="svg")
    fig.savefig("%s_%s_all_mean_noise.png"%(metric_i, inputfile), dpi=1000, format="png")
    plt.show(block=False)
