# importing libraries
import numpy as np
from scipy.io import loadmat
#import spikeforest as sf
import matplotlib.pyplot as plt
import umap
import hdbscan
from scipy.spatial.distance import cdist
import seaborn as sns
import pandas as pd
from sklearn.decomposition import PCA 
from matplotlib.colors import ListedColormap
import matplotlib.gridspec as gridspec
import random
import pywt
from scipy import stats
import pickle as pkl        # probably Vik needs to install this library, 
import SpkSort as s
from os import path as p
from os import listdir
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

import warnings                           # FOr silencing warnings
from constants import *                 # Import namefiles, dictionaries, paths, etc.

warnings.filterwarnings("ignore")

#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#                            Parameters for this script
#----------------------------------------------------------------------------------------------------------------------
nreps=20                  # Number of repetitions for every fraction (estimation of the f-score)
fractions=np.arange(0.2, 1.05, 0.2)           # Fraction of spikes remaining
type_i="easy"
delta=25                  # Parameter to indicate if both spikes are the same shifted in samples (delta*0.04166667 in ms)
min_features=2            # Minimimum dimensionality or # of components to explore.
maximum_features=15       # Maximum dimensionality to explore
#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------


fscore_results={}         # dictionary where results will be saved
clasification={}
types_file=files.keys()   # Types of file. see above cell
list_existing_files=listdir()

# for type_i in types_file:
print("Executing %s files"%(type_i))
for file_i in files[type_i]:   
    # Dictionary with results per type of file
    print("\tAnalyzing %s file"%(file_i[0]))
    fscore_results[file_i[0]]={"noise":file_i[1],
                    "pca": np.zeros((maximum_features-min_features, len(fractions), nreps, 3)), 
                    "umap": np.zeros((maximum_features-min_features,len(fractions), nreps, 3)), 
                    "waveclus": np.zeros((maximum_features-min_features,len(fractions), nreps, 3))} 
    
    spikes, labels, spike_times = s.load_quiroga_spikes(p.join(path, file_i[0]) )  
    clusters=np.unique(labels)
    denoised = s.denoiser(spikes)
    spikes2 = s.aligner(denoised, alignment="tukey", window_length=30, upsample_rate=8) 
    for lab_idx, lab_i in enumerate(clusters):
        print("\t cluster: %d"%(lab_i))
        for frac_idx, fraction_i in enumerate(fractions):
            for rep_i in range(nreps):
                print("\t\t fractions: %.2f, rep_i: %d"%(fraction_i, rep_i+1))
            # Calculating values with the whole set
                if fraction_i==1:
                    wavefrms, labls, spktm=(spikes2, labels, spike_times)
                else:
                    wavefrms, labls, spktm =s.silente2(spikes2, labels, spike_times, lab_i, fraction_i)
                    
                reducer_waveclus = s.waveclus(wavefrms, maximum_features)
                reducer_pca= PCA(maximum_features).fit_transform(wavefrms)
                for dim_i in range(min_features, maximum_features):
                    clusterer_waveclus= hdbscan.HDBSCAN(min_cluster_size=30, min_samples=5, cluster_selection_epsilon=.6).fit(reducer_waveclus[:, 0:dim_i])
                    clasification["waveclus"]= clusterer_waveclus.labels_
                    #  sep per technique
                    clusterer_pca= hdbscan.HDBSCAN(min_cluster_size=30, min_samples=5, cluster_selection_epsilon=.6).fit(reducer_pca[:, 0:dim_i])
                    clasification["pca"]= clusterer_pca.labels_
                    
                    reducer_umap= umap.UMAP(min_dist=0, n_neighbors=4, n_components=dim_i, n_epochs=2000, random_state=0, metric="manhattan").fit(wavefrms)
                    umap_emb = reducer_umap.embedding_.copy()
                    clusterer_umap = hdbscan.HDBSCAN(min_cluster_size=30, min_samples=5, cluster_selection_epsilon=.6).fit(reducer_umap.embedding_)
                    clasification["umap"] = clusterer_umap.labels_
                    # Now measure f-score per file and techinique
                    #raise ValueError("Aqui vamos")
                    for technique_i in clasification.keys():
                        fscore_tmp=s.f_recording(spktm, labls, clasification[technique_i], delta)
                        fscore_results[file_i[0]][technique_i][dim_i-min_features, frac_idx, rep_i, lab_idx]=fscore_tmp
                
# Saving results to a file
    tmp=file_i[0][:-4]
    with open("Deletion_from_%d_to_%d_umap_pca_wav_%dreps_%s_%s.pkl"%(min_features, maximum_features, nreps, type_i, tmp), "wb") as file1:
        pkl.dump(fscore_results, file1)
    print("File saved")