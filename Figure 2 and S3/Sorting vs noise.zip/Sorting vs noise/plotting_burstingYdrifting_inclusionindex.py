import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt

with open("Analysis_from_2_to_15_pca_wav_incl_index_UMAP_new_method_BurstingDrifting_optim.pkl", 'rb') as f:
    data=pkl.load(f)

datadrift=data["Index_Inclusion"]["C_Drift_Easy2_noise015.mat"]
databurst=data["Index_Inclusion"]["C_Burst_Easy2_noise015.mat"]

dimm=np.arange(2, 15)
fig, ax=plt.subplots(1,2)
for reducer_i in datadrift.keys():
    if reducer_i!="noise":
        ax[0].plot(dimm, datadrift[reducer_i], label=reducer_i)
        
for reducer_i in databurst.keys():
    if reducer_i!="noise":
        ax[1].plot(dimm, databurst[reducer_i], label=reducer_i)
for ax_i in ax.flatten():        
    ax_i.spines[['right', 'top']].set_visible(False)
    ax_i.set_xlabel("Dimmensions")

ax[0].set_ylabel("Index Inclusion")
ax[1].legend(loc="best", frameon=False)
ax[0].set_title("Drifting")
ax[1].set_title("Bursting")

fig.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig.savefig("f-scorevsDimm_drifting_index_score_30nnumap.svg")
fig.savefig("f-scorevsDimm_drifting_index_score_30nnumap.png", dpi=500)