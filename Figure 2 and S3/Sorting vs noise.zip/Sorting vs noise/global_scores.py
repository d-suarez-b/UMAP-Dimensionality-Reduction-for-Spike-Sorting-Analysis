# Now plotting
import pickle as pkl
import matplotlib.pyplot as plt
from matplotlib import colormaps

import numpy as np
import sys
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

x=np.arange(2, 15)

#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#                            Parameters for this script
#----------------------------------------------------------------------------------------------------------------------
                        
# You can now retrieve arguments passed from the calling script
inputfile = sys.argv[1]        # nreps=20    # Number of repetitions for every fraction (estimation of the f-score)
inputfile2=sys.argv[2]
#-------
with open (inputfile, "rb") as f:
    data=pkl.load(f)

with open (inputfile2, "rb") as f:
    data2=pkl.load(f)
diff=data2['DaviesBouldin']

files=('C_Easy1_noise01.mat', 'C_Easy1_noise02.mat', 'C_Easy1_noise005.mat', 'C_Easy1_noise015.mat', 'C_Difficult1_noise01.mat', 'C_Difficult1_noise02.mat', 'C_Difficult1_noise005.mat', 'C_Difficult1_noise015.mat', 'C_Difficult2_noise01.mat', 'C_Difficult2_noise02.mat', 'C_Difficult2_noise005.mat', 'C_Difficult2_noise015.mat')

c=["red", "green", "magenta", "blue"]
techs=["pca", "waveclus", "umap"]

for metric_idx, metric_i in enumerate(data.keys()):
    pooling_data={"pca":[], "waveclus":[], "umap":[]}
    pooling_diff={"pca":[], "waveclus":[], "umap":[]}
    for file_i in files:
        for col_idx, tech_i in enumerate(techs):
            pooling_data[tech_i].append(data[metric_i][file_i][tech_i])
            pooling_diff[tech_i].append(diff[file_i][tech_i])
    # Figure (scatter)
    fig2, ax2=plt.subplots(1,1, sharex=True, sharey=True)
    fig2.suptitle(metric_i)
    for col_idx, tech_i in enumerate(techs):
        tmp=np.array(pooling_data[tech_i]).flatten()
        tmp2=np.array(pooling_diff[tech_i]).flatten()
        ax2.scatter(tmp, tmp2, c=c[col_idx], alpha=0.55, label=tech_i)
        if col_idx==0:
            diff_mat=np.zeros((len(tmp), len(techs)))
            score_mat=np.zeros((len(tmp), len(techs)))
        diff_mat[:, col_idx]=np.copy(tmp2)
        score_mat[:, col_idx]=np.copy(tmp)
    plt.yscale("log")
    plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
    plt.legend(loc="best", frameon=False)
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.set_xlabel(metric_i)
    ax2.set_ylabel("Difficulty")
    fig2.tight_layout()
    fig2.savefig("%s_%s_DiffVsScore.svg"%(metric_i, inputfile), format="svg")
    fig2.savefig("%s_%s_DiffVsScore.png"%(metric_i, inputfile), dpi=1000, format="png")
    plt.show(block=False)
    
 

    fig, axs=plt.subplots(1,1, sharex=True, sharey=True)
    # plot box plot
    axs.boxplot(score_mat, bootstrap=10000, notch=True)
   
    axs.yaxis.grid(True)
    axs.set_xticks([y + 1 for y in range(len(score_mat[0]))],
                  labels=techs)
    axs.set_xlabel(metric_i)
    axs.set_ylabel('Observed values')
    plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
    axs.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig("%s_%s_Boxplot_%s.svg"%(metric_i, inputfile, metric_i), format="svg")
    fig.savefig("%s_%s_Boxplot_%s.png"%(metric_i, inputfile, metric_i), dpi=1000, format="png")
    plt.show(block=False)

    if metric_idx==0:
        fig, axs=plt.subplots(1,1, sharex=True, sharey=True)
    # plot box plot
        axs.boxplot(diff_mat, bootstrap=10000, notch=True)
       
        axs.yaxis.grid(True)
        axs.set_xticks([y + 1 for y in range(len(diff_mat[0]))],
                      labels=techs)
        axs.set_xlabel("Difficulty")
        axs.set_ylabel('Observed values')
        plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
        axs.spines[["top", "right"]].set_visible(False)
        plt.yscale("log")
        fig.tight_layout()
        fig.savefig("%s_%s_Boxplot_Difficulty.svg"%(metric_i, inputfile), format="svg")
        fig.savefig("%s_%s_Boxplot_Difficulty.png"%(metric_i, inputfile), dpi=1000, format="png")
        plt.show(block=False)