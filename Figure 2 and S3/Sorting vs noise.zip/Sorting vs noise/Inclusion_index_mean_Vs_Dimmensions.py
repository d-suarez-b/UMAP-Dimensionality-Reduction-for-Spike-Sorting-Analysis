# Now plotting
import pickle as pkl
import matplotlib.pyplot as plt
from matplotlib import colormaps

import numpy as np
import sys
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

x=np.arange(2, 15)

#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#                            Parameters for this script
#----------------------------------------------------------------------------------------------------------------------
                        
# You can now retrieve arguments passed from the calling script
inputfile = sys.argv[1]        # nreps=20    # Number of repetitions for every fraction (estimation of the f-score)
#-------
with open (inputfile, "rb") as f:
    data=pkl.load(f)
noise=np.array([0.05, 0.1, 0.15, 0.2])
c=["red", "green", "magenta", "blue"]
line_labels = ["$\eta$: %.2f"%(noise[idx]) for idx in range(len(noise)) ]


files=("Easy", "Difficult 1", "Difficult 2")
techs=["pca", "waveclus", "umap"]
pooling={"pca":[], "waveclus":[], "umap":[]}
for metric_i in data.keys():
    fig, ax=plt.subplots(1, 1, sharex=True, sharey=True)
    for dataset_i in data[metric_i].keys():
        for col_idx, tech_i in enumerate(techs):
            pooling[tech_i].append(data[metric_i][dataset_i][tech_i])
            
    for col_idx, tech_i in enumerate(techs):
        tmp=np.mean(np.vstack(pooling[tech_i]), axis=0)
        ax.plot(x, tmp, label=tech_i, c=c[col_idx])
        print(metric_i,  tech_i, "mean: ",  np.mean(tmp))
        ax.legend(loc="best", frameon=False) #bbox_to_anchor=(1.1, 1.05)
    
        ax.set_ylabel("%s"%(metric_i))
        ax.set_xlabel("Dimmensions")
        ax.spines[["top", "right"]].set_visible(False)
    

    plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
    fig.tight_layout()
    fig.savefig("%s_%s_average_all.svg"%(metric_i, inputfile), format="svg")
    fig.savefig("%s_%s_average_all.png"%(metric_i, inputfile), dpi=1000, format="png")
    plt.show(block=False)