import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt
from copy import copy

namefig="fscore_vs_Noise.svg"

dimensions={"pca":0, "umap":0, "waveclus":8}
namefiles= ( "C_Easy1_noise01.mat",
             "C_Easy1_noise02.mat",
            "C_Easy1_noise005.mat", 
            "C_Easy1_noise015.mat",
            "C_Difficult1_noise01.mat",
            "C_Difficult1_noise02.mat",
            "C_Difficult1_noise005.mat", 
            "C_Difficult1_noise015.mat",
            "C_Difficult2_noise01.mat",
            "C_Difficult2_noise02.mat", 
            "C_Difficult2_noise005.mat", 
            "C_Difficult2_noise015.mat", )
noise=np.array((0.05, 0.1, 0.15, 0.2))
# Array containing info per dimmXnoiseXfile
ntipes=len(namefiles)//4
fscore={"umap":np.zeros((13, 4, ntipes)),
        "pca":np.zeros((13, 4, ntipes)),
        "waveclus":np.zeros((13, 4, ntipes))}
with open("Analysis_from_2_to_15_pca_wav.pkl", 'rb') as f:
    data=pkl.load(f)

# Organizing data for the same dimensionality (row), and same noise (column), and number of file
for file_idx, file_i in enumerate(namefiles):
    file_idxx=file_idx//4
    idx=np.where(noise==data[file_i]["noise"])[0]
    for reducer_i in ("umap", "pca", "waveclus"):
        # print(file_i, reducer_i, (data[file_i][reducer_i]).shape)
        for dimm_i in range(13):
            fscore[reducer_i][dimm_i, idx, file_idxx]=data[file_i][reducer_i][dimm_i]
    
# Extracting mean and standard deviation dependent of noise and reducer

fig, ax=plt.subplots(1, 1)
statistic=np.zeros((3, 4, 3)) #Saludos al vic
for reducer_idx, reducer_i in enumerate( ("umap", "pca", "waveclus")):
    for noise_i in range(4):
        statistic[0, noise_i, reducer_idx]=np.nanquantile(fscore[reducer_i][:, noise_i, :].flatten(), 0.05)
        statistic[1, noise_i, reducer_idx]=np.nanmean(fscore[reducer_i][:, noise_i, :])
        statistic[2, noise_i, reducer_idx]=np.nanstd(fscore[reducer_i][:, noise_i, :].flatten())

# Now plotting
for reducer_idx, reducer_i in enumerate( ("umap", "pca", "waveclus")):
    ax.errorbar(noise, statistic[1, :, reducer_idx], 
                    yerr=statistic[2, :, reducer_idx]/np.sqrt(ntipes*13),
                    #statistic[2, :, reducer_idx], alpha=0.75,
                    label=reducer_i )

ax.spines[['right', 'top']].set_visible(False)
ax.set_xlabel("Noise")
ax.set_ylabel("Fscore")
plt.legend(loc="best", frameon=False)
plt.title("F-score (including dimm from 2-14) as a function of noise")
fig.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig.savefig(namefig, format="svg")

# Now plotting just the easy 1 files
# Organizing data for the same dimensionality (row), and same noise (column), and number of file
easy={"umap":np.zeros((8)), 
      "pca":np.zeros((8)), 
      "waveclus":np.zeros((8))}
for file_idx, file_i in enumerate(( "C_Easy1_noise005.mat",
                                    "C_Easy1_noise01.mat",
                                    "C_Easy1_noise015.mat",
                                    "C_Easy1_noise02.mat",
                                    "C_Easy1_noise025.mat",
                                    "C_Easy1_noise03.mat",
                                    "C_Easy1_noise035.mat",
                                    "C_Easy1_noise04.mat",
                                   )):
    idx=np.where(noise==data[file_i]["noise"])[0]
    for reducer_i in ("umap", "pca", "waveclus"):
        # print(file_i, reducer_i, (data[file_i][reducer_i]).shape)
        easy[reducer_i][file_idx]=np.mean(data[file_i][reducer_i])

print(easy)
# Now plotting
noise2=np.array((0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4))
fig2, ax2=plt.subplots(1, 1)
for reducer_idx, reducer_i in enumerate( ("umap", "pca", "waveclus")):
    ax2.plot(noise2, easy[reducer_i], label=reducer_i )

ax2.spines[['right', 'top']].set_visible(False)
ax2.set_xlabel("Noise")
ax2.set_ylabel("Fscore")
plt.legend(loc="best", frameon=False)
plt.title("F-score (Best performance) as a function of noise. File: easy 1")
fig2.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig2.savefig("Fscore_vs_noise_easy1Files.svg", format="svg")
