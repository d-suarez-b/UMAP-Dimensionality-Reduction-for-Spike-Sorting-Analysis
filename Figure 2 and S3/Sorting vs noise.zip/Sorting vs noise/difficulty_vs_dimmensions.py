# Parameters for this script
num_features={"waveclus": 10, "PCA":2, "UMAP":2}    # Optimal dimmensionality
fscore_results={}         # dictionary where results will be saved
confmat_results={}         # dictionary where results will be saved
delta=25                  # Parameter to indicate if both spikes are the same shifted in samples (delta*0.04166667 in ms)
min_features=2            # Minimimum dimensionality or # of components to explore.
maximum_features=15       # Maximum dimensionality to explore


#--------------------------------------------------------------------------------------------------------------
# importing libraries
# FOr silencing warnings
import warnings
warnings.filterwarnings("ignore")
import numpy as np
from scipy.io import loadmat
#import spikeforest as sf
import matplotlib.pyplot as plt
#from busz_funcs import pk, pts_extraction, butter_bandpass_filter_zi, load_kachery
#from toposort.preprocessing import spike_denoiser as denoiser, spike_aligner as aligner
import umap
from sklearn.metrics import davies_bouldin_score, silhouette_samples
from scipy.spatial.distance import cdist
import seaborn as sns
import pandas as pd
from sklearn.decomposition import PCA 
#from quiroga import *
from matplotlib.colors import ListedColormap
import matplotlib.gridspec as gridspec
import random
#import umap.plot
import pywt
from scipy import stats
import pickle as pkl        # probably Vik needs to install this library, 
import SpkSort as s
from os import path as p
from os import listdir
from constants import *
#
DaviesBouldin={}
Silhoutte={}

for type_i in types_file:
    print("Executing %s files"%(type_i))
    for file_i in files[type_i]:   
        # Dictionary with results per type of file
        print("\tAnalyzing %s file"%(file_i[0]))
        DaviesBouldin[file_i[0]]={"noise":file_i[1],
                        "pca": np.zeros((maximum_features-min_features)), 
                        "umap": np.zeros(maximum_features-min_features), 
                        "waveclus": np.zeros(maximum_features-min_features)}  
        #  NOW silhouette
        Silhoutte[file_i[0]]={"noise":file_i[1],
                        "pca": np.zeros((maximum_features-min_features, 3)),      #mean, median sigma
                        "umap": np.zeros((maximum_features-min_features,3 )),       #mean, median sigma
                        "waveclus": np.zeros((maximum_features-min_features, 3))}   #mean, median sigma
        
        spikes, labels, spike_times = s.load_quiroga_spikes(p.join(path, file_i[0]) )  
        clusters=np.unique(labels)
        denoised = s.denoiser(spikes)
        spikes2 = s.aligner(denoised, alignment="tukey", window_length=30, upsample_rate=8)
        # Calculating values with the whole set
        reducer_waveclus = s.waveclus(spikes2, maximum_features)
        reducer_pca= PCA(maximum_features).fit_transform(spikes2)
        for dim_i in range(min_features, maximum_features):            
            reducer_umap= umap.UMAP(min_dist=0, n_neighbors=file_i[-1][dim_i-2], n_components=dim_i, n_epochs=2000, random_state=0, metric="manhattan").fit(spikes2)
            # Now measuring the difficulty
            DaviesBouldin[file_i[0]]["umap"][dim_i-min_features] =davies_bouldin_score(reducer_umap.embedding_, labels)
            DaviesBouldin[file_i[0]]["pca"][dim_i-min_features] =davies_bouldin_score(reducer_pca[:, 0:dim_i], labels)
            DaviesBouldin[file_i[0]]["waveclus"][dim_i-min_features] =davies_bouldin_score(reducer_waveclus[:, 0:dim_i], labels)
            # Now silhouette metric
            tmp=silhouette_samples(reducer_umap.embedding_, labels)
            Silhoutte[file_i[0]]["umap"][dim_i-min_features, :]=np.array([np.mean(tmp), np.median(tmp), np.std(tmp)])
            tmp=silhouette_samples(reducer_pca[:, 0:dim_i], labels)
            Silhoutte[file_i[0]]["pca"][dim_i-min_features, :]=np.array([np.mean(tmp), np.median(tmp), np.std(tmp)])
            tmp=silhouette_samples(reducer_waveclus[:, 0:dim_i], labels)
            Silhoutte[file_i[0]]["waveclus"][dim_i-min_features, :]=np.array([np.mean(tmp), np.median(tmp), np.std(tmp)])
# Saving results to a file
with open("Difficulty_%d_to_%d_pca_wav_conf_mat_updated_valuesnn_optim.pkl"%(min_features, maximum_features), "wb") as file1:
    pkl.dump({"silhouette":Silhoutte, "DaviesBouldin":DaviesBouldin}, file1)
print("Finished...")