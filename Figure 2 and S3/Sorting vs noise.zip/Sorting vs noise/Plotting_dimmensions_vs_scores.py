# Now plotting
import pickle as pkl
import matplotlib.pyplot as plt
from matplotlib import colormaps

import numpy as np
import sys
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!

x=np.arange(2, 15)

#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------
#                            Parameters for this script
#----------------------------------------------------------------------------------------------------------------------
                        
# You can now retrieve arguments passed from the calling script
inputfile = sys.argv[1]        # nreps=20    # Number of repetitions for every fraction (estimation of the f-score)
#-------
with open (inputfile, "rb") as f:
    data=pkl.load(f)
noise=np.array([0.05, 0.1, 0.15, 0.2])
c=["red", "green", "magenta", "blue"]
line_labels = ["$\eta$: %.2f"%(noise[idx]) for idx in range(len(noise)) ]


files=("Easy", "Difficult 1", "Difficult 2")
techs=["pca", "waveclus", "umap"]
for metric_i in data.keys():
    fig, ax=plt.subplots(3, 3, sharex=True, sharey=True)
    fig.suptitle(metric_i)
    for dataset_i in data[metric_i].keys():
        if "Easy1" in dataset_i:
            namerow="Easy"
            row=0
        elif "Difficult1" in dataset_i:
            namerow="Difficult 1"
            row=1
        else:
            row=2
            namerow="Difficult 2"
        c_idx=np.argmin(np.abs(data[metric_i][dataset_i]["noise"]-noise))
        for col_idx, tech_i in enumerate(techs):
            ax[row, col_idx].plot(x, data[metric_i][dataset_i][tech_i], color=c[c_idx],
                                 label="$\eta = %.2f$"%(noise[c_idx]))
            ax[row, col_idx].spines[["right", "top"]].set_visible(False)
                
 
        #plt.legend(loc="best", frameon=False)
    #plt.figlegend( line_labels, loc = 'lower center', borderaxespad=0.1, ncol=6, labelspacing=0.,  prop={'size': 13} ) #bbox_to_anchor=(0.5, 0.0), borderaxespad=0.1, 
    ax[0, -1].legend(loc="best", frameon=False, bbox_to_anchor=(1.1, 1.05))
    for idx in range(3):
        ax[idx, 0].set_ylabel("%s \n %s"%(metric_i, files[idx]))
        ax[-1, idx].set_xlabel("Dimmensions")
        ax[0, idx].set_title(techs[idx].upper())
    

    plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
    fig.tight_layout()
    fig.savefig("%s_%s_all.svg"%(metric_i, inputfile), format="svg")
    fig.savefig("%s_%s_all.png"%(metric_i, inputfile), dpi=1000, format="png")
    plt.show(block=False)
