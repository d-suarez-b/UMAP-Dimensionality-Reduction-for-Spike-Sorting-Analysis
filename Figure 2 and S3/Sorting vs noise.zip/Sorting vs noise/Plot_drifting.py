import pickle as pkl
import numpy as np
import matplotlib.pyplot as plt

with open("Analysis_from_2_to_15_pca_wav_conf_mat.pkl", 'rb') as f:
    data=pkl.load(f)

datadrift=data["C_Drift_Easy2_noise015.mat"]

dimm=np.arange(2, 15)
fig, ax=plt.subplots(1,1)
for reducer_i in datadrift.keys():
    if reducer_i!="noise":
        plt.plot(dimm, datadrift[reducer_i], label=reducer_i)

ax.spines[['right', 'top']].set_visible(False)
ax.set_xlabel("Dimmensions")
ax.set_ylabel("Fscore")
plt.legend(loc="best", frameon=False)
plt.title("Drifting")
fig.tight_layout()
plt.rcParams['svg.fonttype'] = 'none'     # Export svg text as text and not paths!
plt.show(block=False)
fig.savefig("f-scorevsDimm_drifting.svg")