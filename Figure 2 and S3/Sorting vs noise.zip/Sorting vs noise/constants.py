path="/media/sparra/HDD/article_spike_sorting/Simulator/"

ne_neigh=np.array([30, 30, 30, 30, 22, 15, 15, 15, 15, 15, 15, 15, 15, ])
ne_heigh2=np.ones((maximum_features - min_features +1), dtype=np.int16)*30

namefiles1= ( ("C_Easy1_noise01.mat", 0.1, ne_heigh2),
             ("C_Easy1_noise02.mat", 0.2, ne_heigh2),
             ("C_Easy1_noise03.mat", 0.3, ne_heigh2),
            ("C_Easy1_noise04.mat", 0.4, ne_heigh2),
            ("C_Easy1_noise005.mat", 0.05, ne_heigh2),
            ("C_Easy1_noise015.mat", 0.15, ne_heigh2),
            ("C_Easy1_noise025.mat", 0.25, ne_heigh2),
            ("C_Easy1_noise035.mat", 0.35, ne_heigh2))

namefiles2= (("C_Difficult2_noise01.mat", 0.1, ne_heigh2),
            ( "C_Difficult2_noise02.mat", 0.2, ne_heigh2),
            ("C_Difficult2_noise005.mat", 0.05, ne_heigh2),
             ("C_Difficult2_noise015.mat", 0.15, ne_heigh2))

namefiles3=(("C_Difficult1_noise01.mat", 0.1, ne_heigh2),
             ("C_Difficult1_noise02.mat", 0.2, ne_heigh2),
             ("C_Difficult1_noise005.mat", 0.05, ne_heigh2),
             ("C_Difficult1_noise015.mat", 0.15, ne_heigh2))

namefiles4=(("C_Burst_Easy2_noise015.mat", 0.15, ne_heigh2), )

namefiles5=(("C_Drift_Easy2_noise015.mat", 0.15, ne_heigh),)


files={"easy":namefiles1, "difficult1":namefiles3, "difficult2":namefiles2,
      "bursty":namefiles4, "drifting":namefiles5}

types_file=files.keys()  